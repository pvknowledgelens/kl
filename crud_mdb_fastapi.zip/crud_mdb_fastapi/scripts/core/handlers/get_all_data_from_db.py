# Retrieve all students present in the database
from scripts.database_connection.mongo_connect import student_collection, student_helper


async def retrieve_students():
    students = []
    async for student in student_collection.find():
        students.append(student_helper(student))
    return students