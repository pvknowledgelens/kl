# Add a new student into to the database
from scripts.database_connection.mongo_connect import student_collection, student_helper


async def add_student(student_data: dict) -> dict:
    student = await student_collection.insert_one(student_data)
    new_student = await student_collection.find_one({"_id": student.inserted_id})
    return student_helper(new_student)