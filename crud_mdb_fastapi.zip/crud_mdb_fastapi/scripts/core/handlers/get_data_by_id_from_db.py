# Retrieve a student with a matching ID
from bson import ObjectId

from scripts.database_connection.mongo_connect import student_collection, student_helper


async def retrieve_student(id: str) -> dict:
    student = await student_collection.find_one({"_id": ObjectId(id)})
    if student:
        return student_helper(student)