from bson import ObjectId

from scripts.database_connection.mongo_connect import student_collection


async def delete_student(id: str):
    student = await student_collection.find_one({"_id": ObjectId(id)})
    if student:
        await student_collection.delete_one({"_id": ObjectId(id)})
        return True