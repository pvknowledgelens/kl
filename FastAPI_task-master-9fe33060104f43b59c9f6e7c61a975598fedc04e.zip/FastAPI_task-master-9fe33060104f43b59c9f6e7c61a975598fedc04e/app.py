import uvicorn
from fastapi import FastAPI

from scripts.constants.db_connection import db_connect
from scripts.utils.mongo_utils import create_collection

if __name__ == "__main__":
    try:
        uvicorn.run("scripts.services.main:app", port=8000, reload=True)
    except Exception as e:
        print(str(e))
