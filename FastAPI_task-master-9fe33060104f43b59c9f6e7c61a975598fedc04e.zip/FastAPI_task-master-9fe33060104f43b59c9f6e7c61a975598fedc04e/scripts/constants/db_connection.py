from pymongo import MongoClient

from scripts.constants.application_config import mongo_uri


def db_connect():
    try:
        conn = MongoClient("mongodb://localhost:27017")
        database = conn.employees
        print(conn.list_database_names())
        dblist = conn.list_database_names()
        if database in dblist:
            print("database exist")
        collection = database.employee
        print("mongo connect successfully")
        return database
    except Exception as e:
        print(str(e))

