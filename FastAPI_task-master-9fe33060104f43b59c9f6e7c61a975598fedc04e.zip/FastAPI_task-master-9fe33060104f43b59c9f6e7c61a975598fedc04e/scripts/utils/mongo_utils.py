def create_collection(db):
    collection_name = "employee"
    collection = db[collection_name]
    return collection
