import pandas as pd

from scripts.constants.application_config import file_path


def read_file():
    try:
        dataset = pd.read_csv(file_path)
        return dataset
    except Exception as e:
        print(str(e))
