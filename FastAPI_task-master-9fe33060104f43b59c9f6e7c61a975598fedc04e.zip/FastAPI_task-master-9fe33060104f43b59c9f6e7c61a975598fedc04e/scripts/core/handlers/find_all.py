def read_all(collection):
    response=collection.find({})