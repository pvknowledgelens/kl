def insert_data(collection, data):
    try:
        inserted = collection.insert_many(data.to_dict('records'))
        if inserted:
            return True
        else:
            return False
    except Exception as e:
        print(str(e))
