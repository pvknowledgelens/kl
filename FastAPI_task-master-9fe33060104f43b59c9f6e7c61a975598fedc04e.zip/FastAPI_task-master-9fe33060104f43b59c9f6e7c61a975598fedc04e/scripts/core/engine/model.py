from mongoengine import Document, StringField, ObjectIdField, IntField
from pydantic import BaseModel


class Employee(Document):
    _id: ObjectIdField()
    id: IntField()
    first_name: StringField()
    last_name: StringField()
    gender: StringField()
    phone: StringField()


class employee_insert(BaseModel):
    _id: str
    id: int
    first_name: str
    last_name: str
    gender: str
    phone: str


class employee_update(BaseModel):
    id: int
class employee_delete(BaseModel):
    id:int
