import json

from fastapi import FastAPI
from mongoengine import connect

from scripts.constants.db_connection import db_connect
from scripts.core.engine.model import Employee, employee_insert, employee_update, employee_delete
from scripts.core.handlers.find_all import read_all
from scripts.core.handlers.insert_data import insert_data
from scripts.core.handlers.read_file import read_file
from scripts.utils.mongo_utils import create_collection

app = FastAPI()
connect(db="employees", host="localhost", port=27017)


@app.get("/")
async def root():
    return {"data": "FastAPI CRUD Operations"}


# csv file insert into database
@app.get("/get_details", tags=["read data"])
def get_all_details():
    employees = Employee.objects().to_json()
    emp_dict = json.loads(employees)
    # print(employees)
    return {"data": emp_dict}


# insert data using post method
@app.post("/send_data", tags=['send data'])
def send_data(emp: employee_insert):
    new_employee = employee_insert(id=emp.id,
                                   first_name=emp.first_name,
                                   last_name=emp.last_name,
                                   gender=emp.gender,
                                   phone=emp.phone)
    collection.insert_one(dict(new_employee))
    return {"message": "new data has been inserted"}


# update data using
@app.put("/update_data", tags=["update database"])
def update_data(emp: employee_update):
    update_emp = employee_update(id=emp.id)
    collection.update_one({"id": update_emp.id}, {"$set": {"first_name": "ARJUN"}})
    return {"data": "data updated"}


@app.delete("/delete_data", tags=["delete data"])
def delete_data(emp: employee_delete):
    delete_emp = employee_delete(id=emp.id)
    collection.delete_one({"id": delete_emp.id})
    return {"data": "data deleted"}


# read csv file
data = read_file()
# create database
db = db_connect()
# create collection
collection = create_collection(db)
# insert the csv file into database
insert = insert_data(collection, data)
print("data inserted from csv")
read = read_all(collection)
