import psycopg2


def connect_db():
    try:
        connection = psycopg2.connect(user="root",
                                      password="root",
                                      host="127.0.0.1",
                                      port="5432",
                                      database="student")

        return connection
    except (Exception, psycopg2.Error) as error:
        print("Failed to Connect to DB", error)
