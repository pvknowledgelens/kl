from pymongo import MongoClient

client = MongoClient('localhost', 27017)  # 27017 is the default port number for mongodb
