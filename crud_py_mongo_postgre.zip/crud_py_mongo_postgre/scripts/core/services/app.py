from scripts.core.config.postgres_connection import connect_db
from scripts.core.database.mongodb import db_connect
from scripts.core.handlers.mongo_db.delete_many_mongodb import delete_many_document
from scripts.core.handlers.mongo_db.delete_one_mongodb import delete_one_document
from scripts.core.handlers.mongo_db.read_one_mongodb import finding_one, finding_many
from scripts.core.handlers.mongo_db.insert_one_mongodb import inserting_one
from scripts.core.handlers.mongo_db.insert_many_mongodb import inserting_many
from scripts.core.handlers.mongo_db.update_one_mongodb import update_one_document
from scripts.core.handlers.mongo_db.updatw_many_mongodb import update_many_document
from scripts.core.handlers.posgres_db.delete_postgresql import delete_row
from scripts.core.handlers.posgres_db.insert_postgresql import insert
from scripts.core.handlers.posgres_db.read_data_postgresql import read_data
from scripts.core.handlers.posgres_db.update_postgresql import update_row


def crud_operation_mongodb():
    try:
        choice = int(input(
            " enter which operation to perform\n0.display many\n1.display one\2.insert one\n3.insert many\n4.delete one\n5.delete many\n6.update one \n7. update many"))

        # create a db connection
        db = db_connect()

        # create a collection
        collection = db['students_collection']
        if choice == 0:
            finding_many(collection)
        if choice == 1:
            finding_one(collection)
        if choice == 2:
            inserting_one(collection)
        if choice == 3:
            inserting_many(collection)
        if choice == 4:
            delete_one_document(collection)
        if choice == 5:
            delete_many_document(collection)
        if choice == 6:
            update_one_document(collection)
        if choice == 7:
            update_many_document(collection)
    except Exception as e:
        print("Error-", e)
    finally:
        print("end")

def crud_operations_postgresql():
        try:
            postgresql_connection = connect_db()
            cursor = postgresql_connection.cursor()
            # checking if the table exists
            cursor.execute(f"SELECT * FROM  information_schema.tables WHERE table_name = 'tbl_company'")
            if cursor.fetchone():
                print("Table Already Exists!")
            else:
                postgres_create_query = """CREATE TABLE tbl_company (license_no INT,
                                                                     company_name CHAR(50) NOT NULL, 
                                                                     market_cap INT NOT NULL,
                                                                     revenue_change INT NOT NULL,
                                                                     pat_change INT NOT NULL,
                                                                     PRIMARY KEY( license_no ))"""
                cursor.execute(postgres_create_query)
                postgresql_connection.commit()
                print("Table Created!")
            # inserting records in the table
            insert(postgresql_connection)
            # read or selecting the data in the table
            read_data(postgresql_connection)
            # updating data in the table based on the license number user entered
            update_row(postgresql_connection)
            # deleting data in the table based on the license number user entered
            delete_row(postgresql_connection)


        except Exception as e:
            print("Error-", e)
        finally:
            print("end")
