from scripts.core.config.mongodb_connection import client
import pymongo


def db_connect():
    # create a connection
    try:
        connection = client

        # create a database
        db = connection['students']
    except Exception as e:
        print("Error ", e)
    return db
