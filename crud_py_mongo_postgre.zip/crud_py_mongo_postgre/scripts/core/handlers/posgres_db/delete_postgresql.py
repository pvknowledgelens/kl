def delete_row(connection):
    try:
        cursor = connection.cursor()
        print("------DELETE OPERATION------\n")
        license_no = input("Enter the license no")
        delete_data = f'DELETE FROM tbl_company WHERE license_no={license_no}'
        cursor.execute(delete_data)
        connection.commit()
        print("Row deleted successfully!")
    except Exception as e:
        print("Error ", e)
