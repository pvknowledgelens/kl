def read_data(connection):
    try:
        cursor = connection.cursor()
        print("------SELECT OPERATION------\n")
        view_data = "SELECT * FROM tbl_company"
        cursor.execute(view_data)
        company_records = cursor.fetchall()
        print("Each row and it's columns values")
        for row in company_records:
            print("license_no = ", row[0])
            print("company_name = ", row[1])
            print("market_cap = ", row[2])
            print("revenue_change = ", row[3])
            print("pat_change  = ", row[4], "\n")
    except Exception as e:
        print("Error ", e)
