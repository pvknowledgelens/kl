def update_row(connection):
    try:
        cursor = connection.cursor()
        print("------UPDATE OPERATION------\n")
        license_no = input("Enter the license no")
        print("Choose the field you want to update\n"
              "1.company_name\n"
              "2.market_cap\n"
              "3.revenue_change\n"
              "4.pat_change\n")
        field_choice = int(input("Enter your choice: "))
        if field_choice == 1:
            update_data = input("Enter the data: ")
            update_query = f'update tbl_company SET company_name ={update_data} where license_no={license_no}'
        else:
            if field_choice == 2:
                field_to_update = "market_cap"
            elif field_choice == 3:
                field_to_update = "revenue_change"
            elif field_choice == 4:
                field_to_update = "pat_change"
            update_data = input("Enter the data: ")
            update_query = f'UPDATE tbl_company SET {field_to_update}={update_data} WHERE license_no={license_no}'
        cursor.execute(update_query)
        connection.commit()
        print("Row updated successfully!")
    except Exception as e:
        print("Error ", e)
