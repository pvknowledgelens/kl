from scripts.core.handlers.get_data_postgresql import data_from_user


def insert(connection):
    cursor = connection.cursor()
    print("------INSERT OPERATION------\n")
    insert_table = "INSERT INTO tbl_company(license_no, company_name, market_cap,revenue_change, pat_change) VALUES(" \
                   "%s,%s,%s,%s,%s)"
    row_value = data_from_user()
    cursor.execute(insert_table, row_value)
    connection.commit()
    count = cursor.rowcount
    print(count, "Record inserted successfully into tbl_company table")
