def data_from_user():
    company_license_no = input("Enter the company license no: ")
    company_name = input("Enter the company name: ")
    market_cap = input("Enter the market capital: ")
    revenue_change = input("Enter the revenue change: ")
    pat_change = input("Enter the pat change: ")
    company_document = (company_license_no, company_name, market_cap, revenue_change, pat_change)
    return company_document
