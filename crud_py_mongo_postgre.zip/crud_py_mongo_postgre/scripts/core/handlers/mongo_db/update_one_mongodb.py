def update_one_document(collection):
    try:
        # update one
        updated_one = collection.update_one({'email': "123@gmail,com."},
                                            )
        if updated_one.matched_count == 1:
            print("One document updated!")
        else:
            print("Updating one document failed!")
    except Exception as e:
        print("Error ", e)
