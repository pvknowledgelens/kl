def delete_one_document(collection):
    try:
        # delete one document
        deleted_one = collection.delete_one({"student name": "pv"})
        if deleted_one.acknowledged:
            print("One document deleted")
        else:
            print("Document deletion failed!")
    except Exception as e:
        print("Error ", e)
