def delete_many_document(collection):
    try:
        # delete more than one document
        deleted_many = collection.delete_many({"pat_change": 33.3})
        if deleted_many.acknowledged:
            print("Documents deleted successfully")
        else:
            print("Documents deletion failed!")
    except Exception as e:
        print("Error ", e)
