def update_many_document(collection):
    try:
        # update many
        updated_many = collection.update_many({}, {"$set": {"pat_change": 3.6}})
        if updated_many.matched_count != 0:
            print("Documents updated Successfully!")
        else:
            print("Updating documents failed!")
    except Exception as e:
        print("Error ", e)
