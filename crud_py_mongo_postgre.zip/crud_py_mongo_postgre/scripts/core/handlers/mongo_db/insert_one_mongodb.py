def data_from_user():
    full_name = input("Enter full name: ")
    email= input("Enter email: ")
    course_of_study = input("Enter course: ")
    year = float(input("enter year: "))
    gpa = float(input("Enter gap: "))
    company_document = {
        "full_name": full_name,
        "company_name": email,
        "course_of_study": course_of_study,
        "year": year,
        "gpa": gpa
    }
    return company_document

def inserting_one(collection):
    try:
        # insert one document
        print("------Inserting using insert_one------")
        # get data from user
        data = data_from_user()
        # inserting one document
        inserted_one = collection.insert_one(data)
        if inserted_one.acknowledged:
            print("One document inserted successfully!")
        else:
            print("One document insertion failed!")
    except Exception as e:
        print("Error ", e)

