from scripts.core.handlers.mongo_db.insert_one_mongodb import data_from_user


def inserting_many(collection):
    try:
        # insert more than one document
        print("------Inserting using insert_many------")
        number_of_documents = int(input("Enter the number of documents to be inserted: "))
        document_list = []
        for i in range(0, number_of_documents):
            print("----- Enter the details" + str(i + 1) + " -----\n")
            document_list.append(data_from_user())

        # inserting more than one document
        inserted_many = collection.insert_many(document_list)
        if inserted_many.acknowledged:
            print(str(number_of_documents) + " documents inserted successfully!")
    except Exception as e:
        print("Error ", e)
