
def finding_one(collection):

    try:
        # find one document
        print(list(collection.find({}, {"fullname": 1, "_id": 0, "email": "jdoe@x.edu.ng"})))
    except Exception as e:
        print("Error ", e)


def finding_many(collection):
    try:
        # find one document
        print(collection.find_one())
    except Exception as e:
        print("Error ", e)
