from scripts.core.services.app import crud_operation_mongodb, crud_operations_postgresql

print("Welcome to Python Crud operations \nchoose your db\n"
      "1.MongoDB\n"
      "2.PostgreSQL\n")

choice = int(input("Enter your choice: "))

if choice == 1:
    crud_operation_mongodb()
if choice == 2:
    crud_operations_postgresql()
