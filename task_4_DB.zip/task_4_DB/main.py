

print(" WELCOME TO DATABASE TRAINING USING MONGODB\n")
choice= int ( input(" SPECIFY THE DATABASE : \n 1. MongoDB\n2.PostgresSQL"))
if choice==1:
    print()
if choice==2:
    print()
else:
    print(" wrong entry")