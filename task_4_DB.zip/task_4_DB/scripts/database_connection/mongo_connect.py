import pymongo


def get_db(db_name="EmployeeDB"):
    client = pymongo.MongoClient("mongodb://localhost:27017")
    db = client.get_database(db_name)
    return db
