from pydantic import BaseModel

# this will be our base model for our updating the base emplyee model

from typing import Optional


class EmployeeUpdate(BaseModel):
    id: int
    name: Optional[str]
    email: Optional[str]
    profession: Optional[str]
    level: Optional[str]
