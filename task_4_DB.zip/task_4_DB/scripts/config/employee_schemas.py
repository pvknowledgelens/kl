from pydantic import BaseModel


# this will be base model for employee
class Employee(BaseModel):
    id: int
    name: str
    email: str
    profession: str
    level: str
